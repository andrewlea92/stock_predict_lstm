//
//  viewControllerCell + extension.swift
//  viewPratice
//
//  Created by Jube on 2022/12/22.
//

import Foundation
import UIKit

extension UITableViewCell {
    static var reuseIdentifier: String { "\(Self.self)" }
}
