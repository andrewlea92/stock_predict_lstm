//
//  SearchCollectionViewCell.swift
//  viewPratice
//
//  Created by Jube on 2022/12/22.
//

import UIKit

class SearchCollectionViewCell: UICollectionViewCell {
    
//    @IBOutlet weak var imageShadowView: UIView!
//    @IBOutlet weak var genreType: UILabel!
//    @IBOutlet weak var genreImage: UIImageView!
//    @IBOutlet weak var genreBg: UIView!
//    
//    func imageStyle(){
//        genreImage.transform = CGAffineTransform(rotationAngle: 160/360)
//        imageShadowView.transform = CGAffineTransform(rotationAngle: 160/360)
//        imageShadowView.layer.shadowColor = CGColor(red: 0, green: 0, blue: 0, alpha: 0.3)
//        imageShadowView.layer.shadowRadius = 6
//    }
//    func updatUI(genre: Genres){
//        genreType.text = genre.type
//        genreBg.backgroundColor = genre.color
//        genreImage.image = UIImage(named: genre.imageName)
//        imageStyle()
//    }
}



