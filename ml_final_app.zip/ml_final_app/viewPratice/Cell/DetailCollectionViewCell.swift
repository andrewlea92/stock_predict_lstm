//
//  DetailCollectionViewCell.swift
//  viewPratice
//
//  Created by Jube on 2022/12/24.
//

import UIKit

class DetailCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var detailAlbumImage: UIImageView!
    
    
    
}
